package chess;

public enum PlayerColor {
  WHITE, BLACK
}
